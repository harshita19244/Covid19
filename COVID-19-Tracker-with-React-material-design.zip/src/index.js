import React from 'react';
import ReactDom from 'react-dom';
import App from './App';

//first component is App, second parameter is the element we want to render it on
ReactDom.render(<App />, document.getElementById('root'));